import React, { Component } from 'react';
import {
  AppRegistry,
  View,
  Text,
  Navigator,
  TouchableOpacity,
  WebView
} from 'react-native';


import StatusBar from '../Components/SharedComponents/StatusBar'

//import Spinner from 'react-native-loading-spinner-overlay';


class Main extends Component{


  componentDidMount(){
    //alert("Did");
  }
  componentWillMount(){
    //alert("will");
  }

    render(){

        return(

            // <View style={{ flex: 1 }}>
            //     <Spinner visible={this.state.visible} />
            // </View>
           //<View>
           
            //<StatusBar title="Main Screen"  navigator={this.props.navigator}/>
            
            
            <WebView
            source={{uri: 'http://www.deeptipublications.com'}}
            style={{marginTop: 20}}
            javaScriptEnabled={true}
            domStorageEnabled={true}
            decelerationRate="normal"
            startInLoadingState={true}


            />
           //// </View>

        );



        
        // return(

        //     <View>

        //     <StatusBar title="Main Screen" icon="arrow-left" navigator={this.props.navigator}/>
        //     <View style={{
        //         marginTop : 40,
        //         justifyContent : 'center',
        //         alignItems : 'center',
                
        //     }}>

        //     <Text>
        //     Main Screen --  Launched after splash Screen
        //     </Text>

        //     <TouchableOpacity
        //     onPress = {()=>{
        //         //alert("test !!!")
        //         this.props.navigator.push({name:'login'})
        //     }}
        //     >
        //     <Text>
        //     Login Screen
        //     </Text>
        //     </TouchableOpacity>
        //     </View>


        //     </View>
        // );
        
    }


}


export default Main